import React, { lazy } from "react";
import ErrorPage from "@components/ErrorPage";
const FormPage = lazy(() => import("../pages/FormPage"));

import { createBrowserRouter, Navigate } from "react-router-dom";


const routes = [
  {
    path: "/exam/",
    element: <FormPage />,
  },
];

export { routes };

export default createBrowserRouter(routes);
