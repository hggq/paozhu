import React, { lazy } from "react";
import ErrorPage from "@components/ErrorPage";
import LoginPage from "../layout/components/Login";
import App, { authLoader } from "../App";
import { createBrowserRouter, Navigate } from "react-router-dom";
import {
  DashboardOutlined,
  EditOutlined,
  TableOutlined,
  BarsOutlined,
  UserOutlined,
} from "@ant-design/icons";

const Dashboard = lazy(() => import("../pages/Dashboard"));
const FormPage = lazy(() => import("../pages/FormPage"));
const TablePage = lazy(() => import("../pages/TablePage"));
const AccountCenter = lazy(() => import("../pages/AccountPage/AccountCenter"));
const AccountSettings = lazy(
  () => import("../pages/AccountPage/AccountSettings")
);
const DetailPage = lazy(() => import("../pages/DetailPage"));

const routes = [
  {
    path: "/psy/",
    element: <App />,
    loader: authLoader,
    children: [
      {
        errorElement: <ErrorPage />,
        children: [
          {
            path: "/psy/",
            title: "系统看板",
            icon: <DashboardOutlined />,
            element: <Dashboard />,
          },
          {
            path: "/psy/sysaccount",
            title: "我的设置",
            icon: <UserOutlined />,
            children: [
              {
                path: "/psy/sysaccount/center",
                title: "个人中心",
                element: <AccountCenter />,
              },
              {
                path: "/psy/sysaccount/settings",
                title: "个人设置",
                element: <AccountSettings />,
              },
            ],
          },
          {
            path: "/psy/exammar",
            title: "详细页面",
            icon: <EditOutlined />,
            element: <DetailPage />,
          },

          {
            path: "/psy/customermar",
            title: "表单样式",
            icon: <EditOutlined />,
            element: <FormPage />,
          },
          {
            path: "/psy/syshelp",
            title: "表哥数据",
            icon: <EditOutlined />,
            element: <TablePage />,
          },
          {
            path: "*",
            element: <Navigate to="/" replace={true} />,
          },
        ],
      },
    ],
  },
  {
    path: "/login",
    element: <LoginPage />,
  },
];

export { routes };

export default createBrowserRouter(routes);
