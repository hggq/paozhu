import React, { lazy } from "react";
import NoAuthPage from "@components/NoAuthPage";
import LoginPage from "../layout/components/MainLogin";

import { createBrowserRouter, Navigate } from "react-router-dom";


const routes = [
  {
    path: "/login",
    element: <LoginPage />,
  },
  {
    path: "/",
    element: <LoginPage />,
  },
];

export { routes };

export default createBrowserRouter(routes);
