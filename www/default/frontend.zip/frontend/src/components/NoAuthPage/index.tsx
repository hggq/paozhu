import React from "react";

const NoAuthPage: React.FC = () => {
  return (
    <div
      style={{
        display: "flex",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      暂无权限......
    </div>
  );
};

export default NoAuthPage;
