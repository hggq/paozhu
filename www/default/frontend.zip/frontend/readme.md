前端演示来源于
https://github.com/panyushan-jade/react-template-admin

Paozhu框架修改为多页面入口生成，修改了部分内容

来源也是 MIT license，只做演示404重写技术用，

前端生成三个目录，paozhu框架利用404重写分发到三个不同目录

解压后 先安装依赖包

pnpm install 
pnpm build
pnpm start