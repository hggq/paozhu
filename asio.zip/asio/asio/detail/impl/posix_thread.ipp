//
// detail/impl/posix_thread.ipp
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2026 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef ASIO_DETAIL_IMPL_POSIX_THREAD_IPP
#define ASIO_DETAIL_IMPL_POSIX_THREAD_IPP

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif // defined(_MSC_VER) && (_MSC_VER >= 1200)

#include "asio/detail/config.hpp"

#if defined(ASIO_HAS_PTHREADS)

#include "asio/detail/posix_thread.hpp"
#include "asio/detail/throw_error.hpp"
#include "asio/error.hpp"

#include "asio/detail/push_options.hpp"

namespace asio {
ASIO_INLINE_NAMESPACE_BEGIN
namespace detail {

posix_thread::~posix_thread()
{
  if (arg_)
    std::terminate();
}

void posix_thread::join()
{
  if (arg_)
  {
    ::pthread_join(arg_->thread_, 0);
    arg_->destroy();
    arg_ = 0;
  }
}

std::size_t posix_thread::hardware_concurrency()
{
#if defined(_SC_NPROCESSORS_ONLN)
  long result = sysconf(_SC_NPROCESSORS_ONLN);
  if (result > 0)
    return result;
#endif // defined(_SC_NPROCESSORS_ONLN)
  return 0;
}

posix_thread::func_base* posix_thread::start_thread(func_base* arg)
{
  int error = ::pthread_create(&arg->thread_, 0,
        ASIO_VERSIONED_NAME(detail_posix_thread_function), arg);
  if (error != 0)
  {
    arg->destroy();
    asio::error_code ec(error,
        asio::error::get_system_category());
    asio::detail::throw_error(ec, "thread");
  }
  return arg;
}

void* ASIO_VERSIONED_NAME(detail_posix_thread_function)(void* arg)
{
  static_cast<posix_thread::func_base*>(arg)->run();
  return 0;
}

} // namespace detail
ASIO_INLINE_NAMESPACE_END
} // namespace asio

#include "asio/detail/pop_options.hpp"

#endif // defined(ASIO_HAS_PTHREADS)

#endif // ASIO_DETAIL_IMPL_POSIX_THREAD_IPP
